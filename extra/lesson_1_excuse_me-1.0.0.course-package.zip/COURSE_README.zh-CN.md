# 对不起！

## 协议

- CoursePackage schema: 1.0
- courseSemantics: 0.1
- courseType: image_dialogue
- 本文件和 `course-package.schema.json` 用于导入方开发和验包，不规定具体 UI。

## 课程说明

包含场景内容和英语练习的互动对话课程。

## 学习顺序

1. 阅读场景对话和辅助翻译。
2. 使用英文单词或短语片段补全句子。
3. 课程提供自由输入时，使用英文输入完成练习。

## 模块

- 核心课程：story graph

## 导入约定

- `npcMessage` / scene dialogue：场景或说话人内容。
- `sourceText`：学习者需要理解或表达的标准目标句。
- `input.prompt`：练习说明，不是对话正文。
- `clozeTemplate` + `gaps`：填空句子、空位和英文片段选项。
- 资源路径以 `package-manifest.json` 为准，并必须通过文件哈希校验。
